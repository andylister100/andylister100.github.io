library(tidyverse)
library(dplyr)
library(mase)

######Note, this definitely works when there is one pre-stratum. I'm not 100% sure it will work for various pre-strata. I could easily do a loop to loop through pre-strata though. For now, let's assume 1 prestratum and 4 post-strata. 
#input files must have same format as those listed.
######
#get stratum weight file name:
(fn =file.choose())
fn #"T:\\FS\\RD\\NRS\\Science\\FIA\\Project\\Inventory\\GIS\\alisterRestricted\\Peru\\2023\\PowerBIFreddy\\areas_pre_pos_estrato.csv"

stratum_weights = read.csv(fn)
#correct name of area column to Nh
names(stratum_weights)[3] = "Nh"

stratum_weights$prepost =paste(stratum_weights$prestrat,"_",stratum_weights$poststrat,sep="")
stratum_weights <- stratum_weights %>%
  group_by(prestrat) %>%
  mutate(Nprestrat = sum(Nh))

(fn2=file.choose())
fn2 #"T:\\FS\\RD\\NRS\\Science\\FIA\\Project\\Inventory\\GIS\\alisterRestricted\\Peru\\2023\\PowerBIFreddy\\datos_orig.csv"
df=read.csv(fn2, header = TRUE, check.names = FALSE)

#for the example, do the 2020-2021 transition. ### I could make this a loop as well, to loop through a list of combinations. For  now, it's hard coded ###
df$trans = paste(df$'2020', "_", df$'2021',sep="")

# Calculate the count of each unique text string by plotid
counts <- df %>%
  group_by(plotid, trans) %>%
  summarize(count = n()) %>%
  ungroup()

# Calculate the total count of pointids by plotid
plot_counts <- counts %>%
  group_by(plotid) %>%
  summarize(total = sum(count))

# Calculate the proportions for each unique text string, by plotid
proportions <- counts %>%
  left_join(plot_counts, by = "plotid") %>%
  mutate(proportion = count / total) %>%
  select(plotid, trans, proportion)

#turn it back into the table I'm expecting
df <- proportions %>%
  pivot_wider(names_from = trans, values_from = proportion, values_fill = 0)

#get the stratum label attached to each plot-level summary
(fn3=file.choose())
fn3 #"T:\\FS\\RD\\NRS\\Science\\FIA\\Project\\Inventory\\GIS\\alisterRestricted\\Peru\\2023\\PowerBIFreddy\\asignacion_estrato_pre_y_post_punto_central.csv"
dfstrat=read.csv(fn3, header = TRUE, check.names = FALSE)
dfm=merge(df,dfstrat)#left join on common field plotid
#prepare the input file by joining strata
dfm$prepost =paste(dfm$prestrat,"_",dfm$poststrat,sep="")
dfm <- merge(dfm, stratum_weights) 

#add helper information (some of which is not necessary):
dfm<- dfm %>%
  group_by(prestrat) %>%
  mutate(nEU=n())
dfm<- dfm %>%
  group_by(prepost) %>%
  mutate(nh=n())
dfm$preWts=dfm$Nprestrat/dfm$nEU
dfm$fpc = 10972887

# Create a data frame for population counts
psPop=stratum_weights[,c(4,3)]

#Now run the post-stratified estimator! Choose the column in dfm that you want to estimate. Note that the survey package will get "close" to what we want, but it won't do the textbook estimator -- the closest is a Taylor series linearization...

#one run, just for demo.
mase::postStrat(y=dfm$TA_H, xsample=dfm$prepost, xpop=as.data.frame(psPop), pi=NULL, N=10972887, var_method = "SRSunconditional", fpc=FALSE, datatype="totals", var_est=TRUE)

#note, the survey package doesn't seem to do the standard "SRSunconditional" variance estimator from the textbooks. MASE does, and the numbers come out the same as the textbook.
names(dfm)


listnames <- names(dfm)[5:14]

results <- data.frame(matrix(NA, nrow = length(listnames), ncol = 6))
colnames(results) <- c("class", "pop_total", "pop_mean", "pop_total_var", "pop_mean_var","sampErrPct")

for(i in seq_along(listnames)){
  y <- dfm[[listnames[i]]]
  
  output <- mase::postStrat(y = y,  
                            xsample = dfm$prepost,
                            xpop = as.data.frame(psPop),
                            pi = NULL, 
                            N = 10972887,
                            var_method = "SRSunconditional",
                            fpc = FALSE,
                            datatype = "totals",
                            var_est = TRUE)
  
  results$class[i] = listnames[i]
  results$pop_total[i] <- output$pop_total
  results$pop_mean[i] <- output$pop_mean
  results$pop_total_var[i] <- output$pop_total_var
  results$pop_mean_var[i] <- output$pop_mean_var
  results$sampErrPct[i] = 100*sqrt(output$pop_total_var)/output$pop_total
}


