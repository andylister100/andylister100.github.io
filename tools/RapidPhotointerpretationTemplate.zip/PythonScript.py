import arcpy
mxd = arcpy.mapping.MapDocument("CURRENT")
df = arcpy.mapping.ListDataFrames(mxd, "Layers")[0]
for pageNum in range(1, mxd.dataDrivenPages.pageCount + 1):
	mxd.dataDrivenPages.currentPageID = pageNum
	print "Exporting page {0} of {1}".format(str(mxd.dataDrivenPages.currentPageID), str(mxd.dataDrivenPages.pageCount))
	df.scale=5000
	arcpy.mapping.ExportToJPEG(mxd, str(pageNum) + ".jpg",
					df,  
					df_export_width=534,
					df_export_height=523,
					resolution=100,
					world_file=True)
del mxd
