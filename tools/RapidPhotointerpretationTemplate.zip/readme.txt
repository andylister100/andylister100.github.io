To use this tool, watch the video at https://www.youtube.com/watch?v=B1xRk9Rjz20.

Note the python script in this directory is used in ArcMap and probably won't work in ArcPro natively -- it relies on "Data Driven Pages". The code will probably need to be adapted to work in ArcPro.